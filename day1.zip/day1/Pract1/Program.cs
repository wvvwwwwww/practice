﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Добро пожаловать в генератор твоей музыкальной группы");
Console.WriteLine("Имя вашего питомца? ");
string _animalName = Console.ReadLine();
Console.WriteLine("Ваш любимый город? ");
string _cityName= Console.ReadLine();
Console.WriteLine($"Название вашей музыкальной группы - {_animalName} из города {_cityName}");
