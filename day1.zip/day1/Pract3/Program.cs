﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract3
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Добро пожаловать в хакерский генератор паролей!");
            int letterCount = GetNonNegativeInt("Сколько букв должно быть в пароле: ");
            int specialCharCount = GetNonNegativeInt("Сколько спецсимволов должно быть в пароле: ");
            int numberCount = GetNonNegativeInt("Сколько чисел должно быть в пароле: ");
            string password = GeneratePassword(letterCount, specialCharCount, numberCount);
            Console.WriteLine($"Ваш пароль: {password}");
        }

        static int GetNonNegativeInt(string message)
        {
            int value;
            while (true)
            {
                Console.Write(message);
                if (int.TryParse(Console.ReadLine(), out value) && value >= 0)
                {
                    return value;
                }
                Console.WriteLine("Ошибка: введите неотрицательное целое число.");
            }
        }

        static string GeneratePassword(int letterCount, int specialCharCount, int numberCount)
        {
            const string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            const string specialChars = "!@#$%^&*()-_=+[]{};:,.<>?";
            const string numbers = "0123456789";

            StringBuilder passwordBuilder = new StringBuilder();
            Random random = new Random();
            for (int i = 0; i < letterCount; i++)
            {
                passwordBuilder.Append(letters[random.Next(letters.Length)]);
            }

            for (int i = 0; i < specialCharCount; i++)
            {
                passwordBuilder.Append(specialChars[random.Next(specialChars.Length)]);
            }

            for (int i = 0; i < numberCount; i++)
            {
                passwordBuilder.Append(numbers[random.Next(numbers.Length)]);
            }

            char[] passwordArray = passwordBuilder.ToString().ToCharArray();
            Shuffle(passwordArray, random);

            return new string(passwordArray);
        }

        static void Shuffle(char[] array, Random random)
        {
            for (int i = array.Length - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                char temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
}
    
