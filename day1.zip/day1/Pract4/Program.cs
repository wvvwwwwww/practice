﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract4    
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Добро пожаловать в шифровальщик!");

            while (true)
            {
                Console.WriteLine("Напечатайте «зашифровать» для зашифровки сообщения. Или «расшифровать» для расшифровки:");
                string action = Console.ReadLine().ToLower();

                if (action == "зашифровать")
                {
                    EncryptMessage();
                }
                else if (action == "расшифровать")
                {
                    DecryptMessage();
                }
                else
                {
                    Console.WriteLine("Неверная команда. Пожалуйста, попробуйте снова.");
                }
            }
        }

        static void EncryptMessage()
        {
            try
            {
                Console.WriteLine("Введите сообщение для шифровки без пробелов английскими буквами:");
                string message = Console.ReadLine();
                Console.WriteLine("Введите сдвиг:");
                int shift = int.Parse(Console.ReadLine());

                string encryptedMessage = CaesarCipher(message, shift);
                Console.WriteLine($"Зашифрованный результат: {encryptedMessage}");
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка: введите корректное число для сдвига.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла ошибка: {ex.Message}");
            }
        }

        static void DecryptMessage()
        {
            try
            {
                Console.WriteLine("Введите сообщение для расшифровки:");
                string message = Console.ReadLine();
                Console.WriteLine("Введите сдвиг:");
                int shift = int.Parse(Console.ReadLine());

                string decryptedMessage = CaesarCipher(message, -shift);
                Console.WriteLine($"Расшифрованный результат: {decryptedMessage}");
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка: введите корректное число для сдвига.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла ошибка: {ex.Message}");
            }
        }

        static string CaesarCipher(string message, int shift)
        {
            char[] buffer = message.ToCharArray();
            for (int i = 0; i < buffer.Length; i++)
            {
                char letter = buffer[i];
                letter = (char)(letter + shift);

                if (letter > 'z')
                {
                    letter = (char)(letter - 26);
                }
                else if (letter < 'a')
                {
                    letter = (char)(letter + 26);
                }

                buffer[i] = letter;
            }
            return new string(buffer);
        }
    }
}

