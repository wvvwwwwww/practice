﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Добро пожаловать в SplitMeal, приложение, которое избавит тебя от подсчётов и добавит авторитета в кругу друзей");

        double totalAmount = GetPositiveDouble("Введите общую сумму обеда: ");
        int participants = GetPositiveInt("Введите количество участников обеда: ");
        int tipPercentage = GetTipPercentage();
        double tipAmount = totalAmount * tipPercentage / 100;
        double totalWithTip = totalAmount + tipAmount;
        double amountPerPerson = totalWithTip / participants;

        Console.WriteLine($"Каждый должен заплатить: {amountPerPerson:F2} рублей");
    }

    static double GetPositiveDouble(string message)
    {
        double value;
        while (true)
        {
            Console.Write(message);
            if (double.TryParse(Console.ReadLine(), out value) && value > 0)
            {
                return value;
            }
            Console.WriteLine("Ошибка: введите положительное число.");
        }
    }

    static int GetPositiveInt(string message)
    {
        int value;
        while (true)
        {
            Console.Write(message);
            if (int.TryParse(Console.ReadLine(), out value) && value > 0)
            {
                return value;
            }
            Console.WriteLine("Ошибка: введите положительное целое число.");
        }
    }

    static int GetTipPercentage()
    {
        int tipPercentage;
        while (true)
        {
            Console.Write("Какой процент чаевых Вы оставляете 10, 12, 15: ");
            if (int.TryParse(Console.ReadLine(), out tipPercentage) && (tipPercentage == 10 || tipPercentage == 12 || tipPercentage == 15))
            {
                return tipPercentage;
            }
            Console.WriteLine("Ошибка: введите 10, 12 или 15.");
        }
    }
}


