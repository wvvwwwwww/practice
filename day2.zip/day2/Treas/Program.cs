﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;

namespace Treas
{
    internal class Program
    {

        static string ComputeMd5Hex(string _word)
        {
            using var md5 = MD5.Create();
            byte[] data = Encoding.UTF8.GetBytes(_word);
            byte[] hash = md5.ComputeHash(data);
            var sb= new System.Text.StringBuilder(hash.Length*2);
            foreach (var b in hash) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }

        static string ComputeSha256Hex(string _word)
        {
            using var md5 = SHA256.Create();
            byte[] data = Encoding.UTF8.GetBytes(_word);
            byte[] hash = md5.ComputeHash(data);
            var sb = new System.Text.StringBuilder(hash.Length * 2);
            foreach (var b in hash) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }
        static void Main(string[] args)
        {
            string[] treasures =
                {
                "5f1e2408e2290940d2f77bc688e96378",
                "5ac09104603448a6f905bd494b6d549b",
                "c09d2644aa265a0b675c380b14fe0922",
                "0a9988b6cd69464701873d79b06928030db91412c02f429967628d952438f38b"
                };

            string[] paths = 
            {
                @"C:\\Users\\Анастасия\\Desktop\\day2\\Treas\\wordlist1.txt",
                @"C:\\Users\\Анастасия\\Desktop\\day2\\Treas\\wordlist2.txt",
                @"C:\\Users\\Анастасия\\Desktop\\day2\\Treas\\wordlist3.txt",
                @"C:\\Users\\Анастасия\\Desktop\\day2\\Treas\\wordlist4.txt"
            };
            List<string> allLines = new List<string>();
            foreach  (var file in paths)
            {
                string[] lines = File.ReadAllLines(file);
                allLines.AddRange(lines);
            }
            int n = 0;
            foreach (string work in allLines)
            {
                for (int i = 0; i < treasures.Length; i++)
                {
                    if (ComputeMd5Hex(work) == treasures[i] || ComputeSha256Hex(work) == treasures[i] && n < 4)
                    {
                        Console.WriteLine($"код к treasure{i + 1}: {work} ");
                        n++;
                    }
                    else
                        if (n == 4)
                        break;

                }
                   
            }

        }
    }
}

